const axios = require('axios');

// Function to generate a response from OpenAI based on the Service ID
exports.generateResponse = async (serviceId) => {
    try {
        const prompt = `Provide details about the home improvement service with ID: ${serviceId}.`;

        const response = await axios.post('https://api.openai.com/v1/completions', {
            model: 'text-davinci-003', // Or gpt-3.5-turbo if available
            prompt: prompt,
            max_tokens: 150
        }, {
            headers: {
                'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        return response.data.choices[0].text.trim();
    } catch (error) {
        console.error('Error generating response from OpenAI:', error);
        return 'Unable to generate response from AI.';
    }
};
