const express = require('express');
const router = express.Router();
const submissionController = require('../controllers/submissionController');

// POST route for form submission
router.post('/submit', submissionController.handleSubmission);

module.exports = router;
