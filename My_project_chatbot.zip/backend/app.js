const express = require('express');
const cors = require('cors');
require('dotenv').config(); // To load environment variables

const app = express();
const apiRoutes = require('./routes/api');

// Middleware
app.use(express.json());
app.use(cors()); // Enable CORS for cross-origin requests

// Use API routes
app.use('/api', apiRoutes);

// Root route to check if backend is working
app.get('/', (req, res) => {
    res.send({ message: 'Node.js backend is working!' });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
