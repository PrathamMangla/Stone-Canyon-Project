const express = require('express');
const cors = require('cors');
const Papa = require('papaparse');
const fs = require('fs');
const bodyParser = require('body-parser');
const { OpenAI } = require('openai');  // Correct import for OpenAI

// Initialize OpenAI API with API key
const openai = new OpenAI({
    apiKey: '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',  // Replace with your actual OpenAI API key
});

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Read and parse the CSV file
let questionsData = [];
fs.readFile('./data/corrected_final_home_improvement_services.csv', 'utf8', (err, data) => {
    if (err) {
        console.error('Error reading CSV file:', err);
        return;
    }

    Papa.parse(data, {
        header: true,
        complete: (results) => {
            questionsData = results.data;
        },
    });
});

// Route to get a question and generate talking prompts using OpenAI
app.post('/get-talking-prompt', async (req, res) => {
    try {
        const { currentQuestion } = req.body;

        // Generate a talking prompt using GPT-4
        const prompt = `You are a chatbot assistant helping with home improvement services. Ask the following question in a conversational way: ${currentQuestion}`;
        const response = await openai.chat.completions.create({
            model: 'gpt-4',
            messages: [{ role: 'system', content: prompt }],
        });

        const generatedPrompt = response.choices[0].message.content.trim();
        res.json({ prompt: generatedPrompt });

    } catch (error) {
        console.error('Error generating prompt:', error);
        res.status(500).json({ error: 'Failed to generate prompt' });
    }
});

// Route to get the filtered questions for a specific category
app.post('/get-questions', (req, res) => {
    const { categoryID, categoryName } = req.body;
    const filteredQuestions = questionsData.filter(
        (item) => item['Category ID'] === categoryID && item['Category Name'] === categoryName
    );
    res.json({ filteredQuestions });
});

const PORT = 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
