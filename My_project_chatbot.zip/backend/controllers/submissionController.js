const { generateResponse } = require('../services/openai');

// Handle the form submission
exports.handleSubmission = async (req, res) => {
    try {
        const { serviceId, name, email, phone, address, zipcode } = req.body;

        // Validate the incoming data (add more validation if needed)
        if (!serviceId || !name || !email || !phone || !address || !zipcode) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        // Call OpenAI to generate a response based on the serviceId
        const aiResponse = await generateResponse(serviceId);

        // Return the form submission details and AI response
        return res.status(200).json({
            message: 'Form submitted successfully!',
            ai_response: aiResponse
        });
    } catch (error) {
        console.error('Error handling submission:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
};
