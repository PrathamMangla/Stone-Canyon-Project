// Summary.js
import React from 'react';
import './Summary.css'; // Import CSS for styling

const Summary = ({ userDetails, serviceID }) => {
    return (
        <div className="summary-container">
            <h2>Summary of Your Information</h2>
            <div className="summary-detail">
                <p><strong>Name:</strong> {userDetails.name}</p>
                <p><strong>Email:</strong> {userDetails.email}</p>
                <p><strong>Phone:</strong> {userDetails.phone}</p>
                <p><strong>Zip Code:</strong> {userDetails.zipcode}</p>
                <p><strong>Address:</strong> {userDetails.address}</p>
            </div>
            <div className="summary-service-id">
                <h3>Your Service ID:</h3>
                <p>{serviceID}</p>
            </div>
        </div>
    );
};

export default Summary;
