import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import Summary from './Summary'; // Import the Summary component
import './Chatbot.css'; // Import the CSS file for styling

const Chatbot = () => {
    const [questions, setQuestions] = useState([]);
    const [selectedCategoryID, setSelectedCategoryID] = useState(null);
    const [isCategoryNameSelected, setIsCategoryNameSelected] = useState(false);
    const [filteredQuestions, setFilteredQuestions] = useState([]);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [responses, setResponses] = useState({});
    const [showServiceID, setShowServiceID] = useState(false);
    const [serviceID, setServiceID] = useState(null);
    const [currentQuestion, setCurrentQuestion] = useState('');
    const [options, setOptions] = useState([]);
    const [talkingPrompt, setTalkingPrompt] = useState('');
    const [previousQuestion, setPreviousQuestion] = useState(null);
    const [previousOption, setPreviousOption] = useState(null);
    const [inputValue, setInputValue] = useState('');

    // User details
    const [userDetails, setUserDetails] = useState({
        name: '',
        email: '',
        phone: '',
        zipcode: '',
        address: '',
    });
    const [currentDetailIndex, setCurrentDetailIndex] = useState(0);
    const detailQuestions = [
        "What is your name?",
        "What is your email?",
        "What is your phone number?",
        "What is your zip code?",
        "What is your address?",
    ];

    const [isCollectingUserDetails, setIsCollectingUserDetails] = useState(false);
    const [summary, setSummary] = useState(null); // State to hold summary data

    // Load CSV data
    useEffect(() => {
        const loadCSV = async () => {
            const response = await fetch('corrected_final_home_improvement_services.csv');
            const csvData = await response.text();
            parseCSV(csvData);
        };
        loadCSV();
    }, []);

    const parseCSV = (data) => {
        Papa.parse(data, {
            header: true,
            complete: (results) => {
                console.log('Parsed CSV Data:', results.data);
                setQuestions(results.data);
            },
        });
    };

    const handleCategoryIDSelect = (categoryID) => {
        setSelectedCategoryID(categoryID);
        setIsCategoryNameSelected(false);
        setCurrentQuestionIndex(0);
        setResponses({});
        setShowServiceID(false);
    };

    const handleCategoryNameSelect = async (categoryName) => {
        setIsCategoryNameSelected(true);
        const response = await fetch('http://localhost:5000/get-questions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ categoryID: selectedCategoryID, categoryName }),
        });
        const data = await response.json();
        setFilteredQuestions(data.filteredQuestions);

        const firstQuestionFunnel = data.filteredQuestions[0]['Question Funnel'].split('|')[0].trim();
        const [question, optionsString] = firstQuestionFunnel.split('>').map(part => part.trim());
        setCurrentQuestion(question);
        await fetchTalkingPrompt(question, null, null);

        const allOptions = data.filteredQuestions.flatMap(item => {
            return item['Question Funnel'].split('|')
                .filter(q => q.includes(question))
                .map(q => q.split('>')[1]?.trim())
                .flatMap(optionsString => optionsString ? optionsString.split(',').map(opt => opt.trim()) : []);
        });

        setOptions([...new Set(allOptions)]);
        setCurrentQuestionIndex(0);
    };

    const fetchTalkingPrompt = async (question, previousQuestion, previousOption) => {
        const response = await fetch('http://localhost:5000/get-talking-prompt', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ currentQuestion: question, previousQuestion, previousOption }),
        });

        const data = await response.json();
        setTalkingPrompt(data.prompt);
    };

    const handleOptionSelect = async (selectedOption) => {
        const currentFunnel = filteredQuestions[0]['Question Funnel'].split('|');
        const currentQuestionIndex = Object.keys(responses).length;

        const currentQuestionText = currentFunnel[currentQuestionIndex].split('>')[0].trim();
        setResponses(prev => ({ ...prev, [currentQuestionText]: selectedOption }));

        setPreviousQuestion(currentQuestionText);
        setPreviousOption(selectedOption);

        if (currentQuestionIndex + 1 >= currentFunnel.length) {
            const questionAnswerPairs = currentFunnel.map((q, index) => {
                const [questionText] = q.split('>').map(part => part.trim());
                const answerText = index === currentQuestionIndex ? selectedOption : responses[questionText] || 'No answer';
                return `${questionText} > ${answerText}`;
            }).join(' | ');

            const matchingService = filteredQuestions.find(item => {
                const questionFunnelPairs = item['Question Funnel'].split('|').map(q => {
                    const [qText, ans] = q.split('>').map(part => part.trim());
                    return `${qText} > ${ans.trim()}`;
                }).join(' | ');

                return questionAnswerPairs === questionFunnelPairs;
            });

            setServiceID(matchingService ? matchingService['Service ID'] : 'No matching service found');
            setShowServiceID(true);
            setIsCollectingUserDetails(true);  // Start collecting user details
            setCurrentDetailIndex(0);  // Reset detail index to start asking user details
            await fetchTalkingPrompt(detailQuestions[0], null, null); // Fetch talking prompt for the first detail question
        } else {
            const nextQuestionFunnel = currentFunnel[currentQuestionIndex + 1];
            const [nextQuestion, nextOptionsString] = nextQuestionFunnel.split('>').map(part => part.trim());
            setCurrentQuestion(nextQuestion);

            const nextAllOptions = filteredQuestions.flatMap(item => {
                return item['Question Funnel'].split('|')
                    .filter(q => q.includes(nextQuestion))
                    .map(q => q.split('>')[1]?.trim())
                    .flatMap(optionsString => optionsString ? optionsString.split(',').map(opt => opt.trim()) : []);
            });

            setOptions([...new Set(nextAllOptions)]);
            await fetchTalkingPrompt(nextQuestion, currentQuestionText, selectedOption);
        }
    };

    const handleInputSubmit = async () => {
        if (isCollectingUserDetails) {
            const detailKey = ['name', 'email', 'phone', 'zipcode', 'address'][currentDetailIndex];
            setUserDetails(prev => ({ ...prev, [detailKey]: inputValue })); // Update userDetails with the current input value
    
            // Check if we are at the last detail question (address)
            if (currentDetailIndex === detailQuestions.length - 1) {
                // Capture the last input for address
                setUserDetails(prev => ({ ...prev, [detailKey]: inputValue })); // Ensure final address is saved
                
                setIsCollectingUserDetails(false);  // Stop collecting user details
                setShowServiceID(true);  // Show service ID after collecting all details
    
                // Create summary object with user details and service ID
                const summaryData = {
                    userDetails: {
                        ...userDetails, // Include existing details
                        [detailKey]: inputValue // Capture the last input
                    },
                    serviceID,
                };
                setSummary(summaryData);  // Set the summary data
            } else {
                setCurrentDetailIndex(prev => prev + 1);  // Move to the next detail question
                // Fetch talking prompt for the next detail question
                await fetchTalkingPrompt(detailQuestions[currentDetailIndex + 1], null, null);
            }
        } else {
            const matchedOption = options.find(option => option.toLowerCase() === inputValue.toLowerCase());
            if (matchedOption) {
                await handleOptionSelect(matchedOption);
            } else {
                await handleOptionSelect(inputValue);
            }
        }
        setInputValue('');  // Clear the input after submission
    };
    
    

    const resetChatbot = () => {
        setSelectedCategoryID(null);
        setIsCategoryNameSelected(false);
        setFilteredQuestions([]);
        setCurrentQuestion('');
        setOptions([]);
        setCurrentQuestionIndex(0);
        setResponses({});
        setShowServiceID(false);
        setServiceID(null);
        setPreviousQuestion(null);
        setPreviousOption(null);
        setIsCollectingUserDetails(false);
        setUserDetails({
            name: '',
            email: '',
            phone: '',
            zipcode: '',
            address: '',
        });
        setCurrentDetailIndex(0);  // Reset detail index
        setSummary(null); // Reset the summary
    };

    return (
        <div className="chatbot-container">
            {summary ? ( // Check if summary exists
                <div className="summary-container"> 
                    <h3>Summary:</h3>
                    <p><strong>Name:</strong> {summary.userDetails.name}</p>
                    <p><strong>Email:</strong> {summary.userDetails.email}</p>
                    <p><strong>Phone:</strong> {summary.userDetails.phone}</p>
                    <p><strong>Zip Code:</strong> {summary.userDetails.zipcode}</p>
                    <p><strong>Address:</strong> {summary.userDetails.address}</p>
                    <p><strong>Your Service ID:</strong> {summary.serviceID}</p>
                </div>
            ) : (
                <>
                    {!selectedCategoryID ? (
                        <div>
                            <h2>Select a Category ID:</h2>
                            {[...new Set(questions.map(item => item['Category ID']))].map((categoryID) => (
                                <button key={categoryID} onClick={() => handleCategoryIDSelect(categoryID)} className="chatbot-button">
                                    {categoryID}
                                </button>
                            ))}
                        </div>
                    ) : !isCategoryNameSelected ? (
                        <div>
                            <h2>Select a Category Name:</h2>
                            <div className="options-container">
                                {[...new Set(questions.filter(q => q['Category ID'] === selectedCategoryID).map(item => item['Category Name']))].map((categoryName) => (
                                    <button key={categoryName} onClick={() => handleCategoryNameSelect(categoryName)} className="chatbot-button">
                                        {categoryName}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <>
                            {isCollectingUserDetails ? (
                                <>
                                    <div className="chatbot-message">
                                        <h3>{talkingPrompt || "Thank you for your response! How can I assist you further?"}</h3>
                                    </div>
                                    <input
                                        type="text"
                                        value={inputValue}
                                        onChange={(e) => setInputValue(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && handleInputSubmit()}
                                        placeholder="Your answer"
                                        className="chatbot-input"
                                    />
                                </>
                            ) : (
                                <>
                                    <div className="chatbot-message">
                                        <h3>{talkingPrompt || "Thank you for your response! How can I assist you further?"}</h3>
                                    </div>
                                    {options.length > 0 && !isCollectingUserDetails && (
                                        <div className="options-container">
                                            {options.map((option, index) => (
                                                <button key={index} onClick={() => handleOptionSelect(option)} className="chatbot-button">
                                                    {option}
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                    <input
                                        type="text"
                                        value={inputValue}
                                        onChange={(e) => setInputValue(e.target.value)}
                                        onKeyPress={(e) => e.key === 'Enter' && handleInputSubmit()}
                                        placeholder="Your answer"
                                        className="chatbot-input"
                                    />
                                </>
                            )}
    
                            {showServiceID && (
                                <div className="chatbot-message">
                                    <h3>Your Service ID: {serviceID}</h3>
                                </div>
                            )}
                        </>
                    )}
                    <button onClick={resetChatbot} className="chatbot-button reset-button">Reset Chatbot</button>
                </>
            )}
        </div>
    );
    
};

export default Chatbot;
